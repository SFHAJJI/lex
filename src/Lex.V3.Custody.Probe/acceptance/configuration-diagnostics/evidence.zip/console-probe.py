import json, os, pathlib, subprocess

root = pathlib.Path(__file__).resolve().parents[2]
assembly = root / 'src/Lex.V3.Custody.Probe/bin/Release/net10.0/Lex.V3.Custody.Probe.dll'
assert assembly.is_file()
receipts = []
for version in (None, '1', '2', '2 '):
    environment = {key: value for key, value in os.environ.items()
                   if not key.upper().startswith(('AZURE_', 'LEX_V3_CUSTODY_', 'IDENTITY_', 'MSI_', 'IMDS_'))}
    environment['AZURE_CLIENT_SECRET'] = 'offline-private-value-must-never-escape'
    if version is not None:
        environment['LEX_V3_CUSTODY_DIAGNOSTICS'] = version
    result = subprocess.run(['dotnet', str(assembly), 'write', 'nightly_floor_90d'],
                            env=environment, capture_output=True, timeout=15)
    assert result.returncode == 1 and result.stdout == b''
    assert b'offline-private-value' not in result.stderr
    lines = result.stderr.decode().splitlines()
    assert lines[0] == 'custody_probe_failed'
    if version in ('1', '2'):
        assert len(lines) == 2
        expected_cause = {'kind': 'invalid_operation', 'http_status': None}
        if version == '2':
            expected_cause['configuration_guard'] = {'kind': 'secret_credential', 'setting': 'AZURE_CLIENT_SECRET'}
        assert json.loads(lines[1]) == {'schema': 'lex-v3-custody-probe-diagnostic/' + version,
                                       'event': 'custody_probe_failed', 'causes': [expected_cause],
                                       'truncated': False}
    else:
        assert len(lines) == 1
    receipts.append({'version': version, 'exit': result.returncode,
                     'stdout': result.stdout.decode(), 'stderr': result.stderr.decode()})
(root / 'artifacts/config-diagnostics/console-receipts.json').write_text(json.dumps(receipts, indent=2), encoding='utf-8')
print('4 compiled-process cases passed; fake credentials only; configuration refusal before store creation')
