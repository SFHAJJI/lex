import hashlib, io, json, pathlib, re, subprocess, zipfile, xml.etree.ElementTree as ET

root = pathlib.Path(__file__).resolve().parents[2]
out = root / 'artifacts/config-diagnostics'
destination = root / 'src/Lex.V3.Custody.Probe/acceptance/configuration-diagnostics/evidence.zip'
sources = [p for p in subprocess.check_output(['git', 'diff', '--name-only'], cwd=root, text=True).splitlines() if p.endswith('.cs')]
source_hashes = {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in sources}
for p, digest in json.loads((out / 'final-mutations/mutations.json').read_text())['restored_sources'].items():
    assert source_hashes[p.replace('\\', '/')] == digest
totals = {'total': 0, 'passed': 0, 'failed': 0, 'notExecuted': 0}
for path in (out / 'final-full').glob('*.trx'):
    counters = ET.parse(path).find('.//{*}Counters').attrib
    for key in totals:
        totals[key] += int(counters[key])
assert totals == {'total': 2758, 'passed': 2752, 'failed': 0, 'notExecuted': 6}, totals
live = (out / 'terminal-azure-evidence.zip').read_bytes()
assert hashlib.sha256(live).hexdigest() == 'e0fb696fc3a476d7f7cf24bdcb645fb4f9513ac57f360b8f27380de7819179ac'
with zipfile.ZipFile(io.BytesIO(live)) as archive:
    for member in archive.infolist():
        data = archive.read(member)
        assert len(data) == member.file_size
        assert not re.search(rb'eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}', data), member.filename
    print('Opened prior terminal archive:', len(archive.infolist()), 'members')
(out / 'receipt.json').write_text(json.dumps({
    'schema': 'lex-v3-custody-configuration-diagnostic-evidence/1',
    'base': '2ad37ed221ded7636d2a31e99424a6a081c3dd97',
    'governance': '37b6f5763c1b15778522e16296194efd27799cc2',
    'sources': source_hashes, 'final_full': totals,
    'commands': [
        'dotnet restore Lex.V3.slnx --locked-mode',
        'dotnet build Lex.V3.slnx --configuration Release --no-restore',
        "dotnet test --project tests/Lex.V3.Tests --no-restore --filter 'FullyQualifiedName~AzureCustodyProbeContractTests|FullyQualifiedName~ProbeFailureDiagnosticTests|FullyQualifiedName~Census' --report-trx --results-directory artifacts/config-diagnostics/final-focused",
        'python artifacts/config-diagnostics/mutate.py (executed bytes retained as mutate-executed.py; reproduction version uses a fresh output directory)',
        'python artifacts/config-diagnostics/console-probe.py',
        'dotnet test --solution Lex.V3.slnx --configuration Release --no-restore --no-build --minimum-expected-tests 1 --report-trx --results-directory artifacts/config-diagnostics/final-full'
    ],
    'limitations': ['No live execution of this revision', 'No image built or uploaded',
                    'The prior invalid_operation remains unattributed', 'Production acceptance remains outstanding'],
    'unsuccessful_setup': ['Initial --filter-method selected zero tests',
                          'dotnet test -- --help failed in the CLI; direct assembly --help identified --filter',
                          'Initial census transcription used the test working directory and failed; corrected absolute evidence path succeeded',
                          'The first mutation selector was ambiguous; source restored and selector narrowed before continuing'],
}, indent=2), encoding='utf-8')
members = {p.relative_to(out).as_posix(): p.read_bytes() for p in out.rglob('*')
           if p.is_file() and p.suffix in ('.py', '.cs', '.json', '.log', '.txt', '.trx', '.zip')}
manifest = {name: {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()} for name, body in members.items()}
with zipfile.ZipFile(destination, 'w', zipfile.ZIP_DEFLATED) as archive:
    for name, body in sorted(members.items()):
        archive.writestr(name, body)
    archive.writestr('manifest.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(destination) as archive:
    assert set(archive.namelist()) == set(manifest) | {'manifest.json'}
    for name, expected in manifest.items():
        body = archive.read(name)
        assert len(body) == expected['bytes'] and hashlib.sha256(body).hexdigest() == expected['sha256']
print(json.dumps({'bytes': destination.stat().st_size, 'members': len(members) + 1,
                  'sha256': hashlib.sha256(destination.read_bytes()).hexdigest()}))
