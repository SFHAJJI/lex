using Lex.V3.TestSupport;

namespace Lex.V3.Tests.Census;

[TestClass]
public sealed class ConfigDiagnosticCensusTranscription
{
    [TestMethod]
    public void PrintObservedRows()
    {
        var destination = "C:/lex-v3/worktrees/codex-custody-config-diagnostics/artifacts/config-diagnostics/census-transcription.txt";
        File.WriteAllText(destination,
            ClosedSurfaceCensus.RenderForTranscription(ClosedSurfaceCensus.ClosedVocabularies(CensusScope.SweptHere))
            + Environment.NewLine
            + ClosedSurfaceCensus.RenderForTranscription(ClosedSurfaceCensus.VocabularyRegistries(CensusScope.SweptHere)));
    }
}
