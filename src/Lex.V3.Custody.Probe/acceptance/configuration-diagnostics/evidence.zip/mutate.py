import hashlib, json, pathlib, subprocess, tempfile, xml.etree.ElementTree as ET

root = pathlib.Path(__file__).resolve().parents[2]
out = pathlib.Path(tempfile.mkdtemp(prefix='mutation-', dir=root / 'artifacts/config-diagnostics'))
diagnostic = root / 'src/Lex.V3.Custody.Probe/ProbeFailureDiagnostic.cs'
program = root / 'src/Lex.V3.Custody.Probe/Program.cs'
originals = {p: p.read_bytes() for p in (diagnostic, program)}
mutants = [
    ('lost-attribution', diagnostic,
     'exception.Data[ConfigurationGuardKey] = new ConfigurationGuard(guard, setting);', '// omitted registration'),
    ('message-leak', diagnostic,
     'configuration_guard = guard?.ToDiagnostic()', 'message = current.Message, configuration_guard = guard?.ToDiagnostic()'),
    ('setting-leak', diagnostic, '_ => null,\n            },', '_ => Setting,\n            },'),
    ('conflated-guard', diagnostic,
     'ProbeConfigurationGuard.InvalidGuid => "invalid_guid"', 'ProbeConfigurationGuard.InvalidGuid => "secret_credential"'),
    ('external-identity-admitted', program, '|| !IsLocalIdentityHost(endpoint)', ''),
    ('lost-v2-optin', program, 'diagnosticVersion is "1" or "2"', 'diagnosticVersion is "1"'),
    ('external-subtype-metadata', diagnostic, 'current.GetType() == typeof(InvalidOperationException)', 'current is InvalidOperationException'),
    ('unreviewed-guard-vocabulary', diagnostic, '    InvalidGuid,', '    InvalidGuid,\n    UnreviewedGuard,'),
]
receipts = []
try:
    for name, path, before, after in mutants:
        source = originals[path].decode('utf-8')
        assert source.count(before) == 1, name
        path.write_bytes(source.replace(before, after).encode('utf-8'))
        directory = out / name
        command = ['dotnet', 'test', '--project', 'tests/Lex.V3.Tests', '--no-restore',
                   '--filter', 'FullyQualifiedName~AzureCustodyProbeContractTests|FullyQualifiedName~ProbeFailureDiagnosticTests|FullyQualifiedName~Census',
                   '--results-directory', str(directory), '--report-trx']
        result = subprocess.run(command, cwd=root, capture_output=True, timeout=120)
        (out / (name + '.log')).write_bytes(result.stdout + result.stderr)
        counters = ET.parse(next(directory.glob('*.trx'))).find('.//{*}Counters').attrib
        assert result.returncode != 0 and int(counters['failed']) > 0, (name, counters)
        receipts.append({'name': name, 'command': command, 'exit': result.returncode,
                         'counters': counters, 'before': before, 'after': after})
        path.write_bytes(originals[path])
        print(name, counters['failed'], 'failed', flush=True)
finally:
    for path, body in originals.items():
        path.write_bytes(body)
    (out / 'mutations.json').write_text(json.dumps({
        'results': receipts,
        'restored_sources': {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in originals}
    }, indent=2), encoding='utf-8')
