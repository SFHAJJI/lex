from pathlib import Path
import json
import subprocess

root = Path(__file__).resolve().parents[2]
diagnostic = root / 'src/Lex.V3.Custody.Probe/ProbeFailureDiagnostic.cs'
program = root / 'src/Lex.V3.Custody.Probe/Program.cs'
originals = {p: p.read_bytes() for p in (diagnostic, program)}
cases = [
    ('message-leak', diagnostic, 'new { kind, http_status', 'new { kind, message = current.Message, http_status'),
    ('unbounded-status', diagnostic, 'status is >= 100 and <= 599 ? status : null', 'status'),
    ('ninth-cause', diagnostic, 'causes.Count < 8', 'causes.Count < 9'),
    ('lost-inner-cause', diagnostic, 'current = current.InnerException;', 'current = null;'),
    ('unbounded-type-name', diagnostic, '_ => "unknown",', '_ => current.GetType().Name,'),
    ('policy-integrity-conflation', diagnostic, 'CustodyPolicyException => "custody_policy"', 'CustodyPolicyException => "custody_integrity"'),
    ('lost-opt-in', program, 'Environment.GetEnvironmentVariable("LEX_V3_CUSTODY_DIAGNOSTICS") == "1"', 'true'),
]
results = []
try:
    for name, path, before, after in cases:
        source = originals[path].decode('utf-8')
        assert source.count(before) == 1
        path.write_text(source.replace(before, after), encoding='utf-8', newline='')
        log = root / 'artifacts/diagnostics' / f'mutant-{name}.txt'
        with log.open('wb') as output:
            run = subprocess.run([
                'dotnet', 'test', '--project', 'tests/Lex.V3.Tests/Lex.V3.Tests.csproj',
                '--configuration', 'Release', '--no-restore',
                '--filter', 'FullyQualifiedName~ProbeFailureDiagnosticTests|FullyQualifiedName~AzureCustodyProbeContractTests',
                '--minimum-expected-tests', '1'], cwd=root, stdout=output, stderr=subprocess.STDOUT)
        path.write_bytes(originals[path])
        text = log.read_text(encoding='utf-8-sig')
        assert run.returncode == 2 and 'Assertion' in text, (name, run.returncode, text[-2000:])
        results.append({'mutation': name, 'exitCode': run.returncode, 'testAssertionFailed': True, 'log': log.name})
        print(json.dumps(results[-1]), flush=True)
finally:
    for path, data in originals.items():
        path.write_bytes(data)
    (root/'artifacts/diagnostics/mutation-results.json').write_text(json.dumps(results, indent=2)+'\n', encoding='utf-8')
